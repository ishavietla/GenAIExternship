
#Define Variables
name = "Isha"
age = 21
height = 5.
#print statement
print(f"Hello, my name is {name}, I am {age} years old and {height} tall!" )

