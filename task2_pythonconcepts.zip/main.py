#define number values
num1 = 15
num2= 5

#perform operations and print result
print("The sum of 15 and 5 is", num1 + num2)
print("The difference between 15 and 5 is", num1 - num2)
print("The product of 15 and 5 is", num1 * num2)
print("The quotient of 15 and 5 is", num1 / num2)