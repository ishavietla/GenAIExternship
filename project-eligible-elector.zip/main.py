#ask user to input their age

age = int(input("How old are you: "))
years_left = 18 - age
if age >= 18:
    print("Congratulations! You are eligible to vote. Go make a difference!")
elif age < 18:
    print(f"Oops! You’re not eligible yet. But hey, only {years_left} more years to go!")
