#User input
num = int(input("Enter a number: "))

# Initialize factorial result
factorial = 1

# For loop to calculate the factorial
for i in range(1, num + 1):
    factorial *= i


print(f"The factorial of {num} is {factorial}.")
