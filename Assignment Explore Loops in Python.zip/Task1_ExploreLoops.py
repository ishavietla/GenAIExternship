#user input
number = int(input("Enter Starting Number: "))

#loop to print numbers in decreasing order
while number > 0:
    print(number, end = ' ')
    number -= 1
    
print("Blast Off!")