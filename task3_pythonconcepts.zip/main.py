#prompt user to enter number
user_input = input("Enter an integer number: ")

number = int(user_input)

#condition statements and print
if number > 0:
    print("This number is positive. Awesome!")
elif number < 0:
    print("This number is negative. Better luck next time!")
elif number == 0:
    print("Zero it is. A perfect balance!")
    